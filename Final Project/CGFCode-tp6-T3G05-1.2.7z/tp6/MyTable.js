/**
 * MyTable
 * @param gl {WebGLRenderingContext}
 * @constructor
 */
function MyTable(scene, minS, maxS, minT, maxT) {
	CGFobject.call(this,scene);

	this.minS = minS||0;
 	this.maxS = maxS||1;
 	this.minT = minT||0;
 	this.maxT = maxT||1;

	this.cube=new MyUnitCubeQuad(this.scene, this.minS, this.maxS, this.minT, this.maxT);
	this.cube.initBuffers();

	this.tableAppearance = new CGFappearance(this.scene);
	this.tableAppearance.loadTexture("../resources/images/table.png");
	this.tableAppearance.setAmbient(0.543, 0.27, 0.074, 1);
	this.tableAppearance.setDiffuse(0.543, 0.27, 0.074, 1);
	this.tableAppearance.setSpecular(0.1,0.1,0.1,1);	
	this.tableAppearance.setShininess(50);

	this.ferro = new CGFappearance(this.scene);
	this.ferro.setAmbient(0.75, 0.75, 0.75, 1);
	this.ferro.setDiffuse(0.75, 0.75, 0.75, 1);
	this.ferro.setSpecular(0.75, 0.75, 0.75, 1);	
	this.ferro.setShininess(80);

};

MyTable.prototype = Object.create(CGFobject.prototype);
MyTable.prototype.constructor=MyTable;


MyTable.prototype.display = function() 
{

	
	//desenho do tampo
	this.scene.pushMatrix();
	this.scene.translate(0, 3.5 + 0.3/2, 0);
	this.scene.scale(5, 0.3, 3);
	this.tableAppearance.apply();
	this.cube.display();
	this.scene.popMatrix();

	//desenho das pernas
	this.scene.pushMatrix();

	this.ferro.apply();
	
	//traseria-esquerda 
	this.scene.pushMatrix();
	this.scene.translate(-2.5 + 0.15, 3.5/2, -1.5 + 0.15);
	this.scene.scale(0.3, 3.5, 0.3);
	this.cube.display();
	this.scene.popMatrix();

	//traseira-direita
	this.scene.pushMatrix();
	this.scene.translate(2.5 - 0.15, 3.5/2, -1.5 + 0.15);
	this.scene.scale(0.3, 3.5, 0.3);
	this.cube.display();
	this.scene.popMatrix();

	//dianteira-esquerda
	this.scene.pushMatrix();
	this.scene.translate(-2.5 + 0.15, 3.5/2, 1.5 - 0.15);
	this.scene.scale(0.3, 3.5, 0.3);
	this.cube.display();
	this.scene.popMatrix();

	//dianteira-direita
	this.scene.pushMatrix();
	this.scene.translate(2.5 - 0.15, 3.5/2, 1.5 - 0.15);
	this.scene.scale(0.3, 3.5, 0.3);
	this.cube.display();
	this.scene.popMatrix();


	this.scene.popMatrix();
};